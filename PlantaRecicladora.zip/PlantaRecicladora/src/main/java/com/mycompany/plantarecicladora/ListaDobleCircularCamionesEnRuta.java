/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.plantarecicladora;

/**
 *
 * @author jasso
 */
public class ListaDobleCircularCamionesEnRuta {
private NodoListaDoble cabeza;
    private NodoListaDoble ultimo;

    public ListaDobleCircularCamionesEnRuta() {
        this.cabeza = null;
        this.ultimo = null;
    }

    public void agregarCamionEnRuta(Camion camion) {
        NodoListaDoble nuevoNodo = new NodoListaDoble(camion);

        if (cabeza == null) {
            cabeza = nuevoNodo;
            ultimo = nuevoNodo;
            nuevoNodo.siguiente = nuevoNodo;  
            nuevoNodo.anterior = nuevoNodo;
        } else {
            nuevoNodo.anterior = ultimo;
            nuevoNodo.siguiente = cabeza;
            ultimo.siguiente = nuevoNodo;
            cabeza.anterior = nuevoNodo;
            ultimo = nuevoNodo;
        }
    }

   
        }
      

