/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.plantarecicladora;

/**
 *
 * @author aubog
 */
        public class PlantaRecicladora {

    public static void main(String[] args) {
        
        Menu m = new Menu();
        m.setVisible(true); 

    }
}

